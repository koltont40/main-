DarkRP.declareChatCommand({
    command = "sleep",
    description = "Go to sleep or wake up",
    delay = 1.5
})

DarkRP.declareChatCommand({
    command = "wake",
    description = "Go to sleep or wake up",
    delay = 1.5
})

DarkRP.declareChatCommand({
    command = "wakeup",
    description = "Go to sleep or wake up",
    delay = 1.5
})
